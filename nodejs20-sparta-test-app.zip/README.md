# Use this repo with Jenkins

## About the app
- "app" folder stores Sparta app
- uses Node JS v20
